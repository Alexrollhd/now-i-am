export interface Category {
  _id: string;
  title: string;
  likes: string;
  posts: string;
}
