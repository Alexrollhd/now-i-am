export const environment = {
  production: true,
  apiUrl: 'https://now-i-am.freeddns.org/api',
  apiUrlCountries: 'https://restcountries.com/v3.1',
  webSocketUrl: 'wss://now-i-am.freeddns.org/api/',
  facebookAppId: '1036035837346520',
  googleAppId: '40811209122-h2vmbta5hlsirf6rkjtahnuiv4rdko4u.apps.googleusercontent.com',
  vkAppId: '8157037',
  bugfenderKey: 'NicuPu6y54K3JyYcA7ndczvJ7vJwvs8s',
};
